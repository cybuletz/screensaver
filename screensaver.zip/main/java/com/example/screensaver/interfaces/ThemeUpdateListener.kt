package com.example.screensaver.interfaces

interface ThemeUpdateListener {
    fun onThemeChanged(isDarkMode: Boolean)
}