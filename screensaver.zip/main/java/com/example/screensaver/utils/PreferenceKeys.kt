package com.example.screensaver.utils

object PreferenceKeys {
    const val DEVICE_ADMIN_ACTIVE = "device_admin_active"
    const val DISPLAY_MODE = "display_mode_selection"
    const val DISPLAY_MODE_DREAM = "dream_service"
}