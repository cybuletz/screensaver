package com.example.screensaver.utils

interface RetryActionListener {
    fun onRetry()
}