package com.example.screensaver.utils

interface OnPhotoLoadListener {
    fun onPhotoLoadComplete(success: Boolean)
}