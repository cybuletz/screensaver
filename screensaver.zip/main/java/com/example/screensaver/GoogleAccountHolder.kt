import com.google.android.gms.auth.api.signin.GoogleSignInAccount

object GoogleAccountHolder {
    var currentAccount: GoogleSignInAccount? = null
}